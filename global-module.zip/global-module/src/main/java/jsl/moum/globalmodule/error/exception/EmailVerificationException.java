package jsl.moum.globalmodule.error.exception;

import jsl.moum.globalmodule.error.ErrorCode;

public class EmailVerificationException extends CustomException{
    public EmailVerificationException() {
        super(ErrorCode.EMAIL_VERIFY_FAILED);
    }
}
