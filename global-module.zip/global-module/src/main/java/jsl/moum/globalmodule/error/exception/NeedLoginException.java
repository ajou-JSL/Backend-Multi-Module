package jsl.moum.globalmodule.error.exception;

import jsl.moum.globalmodule.error.ErrorCode;


public class NeedLoginException extends CustomException{
    public NeedLoginException() {
        super(ErrorCode.NEED_LOGIN);
    }
}
