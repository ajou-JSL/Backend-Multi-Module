package jsl.moum.globalmodule.error.exception;

import jsl.moum.globalmodule.error.ErrorCode;
public class DuplicateUsernameException extends CustomException {
    public DuplicateUsernameException() {
        super(ErrorCode.USER_NAME_ALREADY_EXISTS);
    }
}
