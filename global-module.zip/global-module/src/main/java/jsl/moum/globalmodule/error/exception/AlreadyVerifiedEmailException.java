package jsl.moum.globalmodule.error.exception;


import jsl.moum.globalmodule.error.ErrorCode;

public class AlreadyVerifiedEmailException extends CustomException{
    public AlreadyVerifiedEmailException(){super(ErrorCode.EMAIL_ALREADY_VERIFIED);}
}
