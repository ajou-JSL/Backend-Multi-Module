package jsl.moum.globalmodule.error.exception;

import jsl.moum.globalmodule.error.ErrorCode;


public class NoAuthorityException extends CustomException{
    public NoAuthorityException() {
        super(ErrorCode.NO_AUTHORITY);
    }
}
