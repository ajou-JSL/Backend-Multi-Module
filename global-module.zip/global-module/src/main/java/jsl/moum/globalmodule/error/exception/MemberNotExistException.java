package jsl.moum.globalmodule.error.exception;


import jsl.moum.globalmodule.error.ErrorCode;


public class MemberNotExistException extends CustomException{
    public MemberNotExistException(){super(ErrorCode.MEMBER_NOT_EXIST);}
}
